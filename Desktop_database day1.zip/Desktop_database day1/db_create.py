#step1
import sqlite3

#step2 and step3
conn = sqlite3.connect("Bootcamp2023.db")
print(conn)
'''
create table table_name(column-name1 datatype contraint(primary key, notnull, unique...),col2 dattype constraint,...)
'''
#2216196, shahin, ece, btech
#step 4
query= '''create table participants(G_id int primary key,name text not null,branch text not null,study text not null)'''


#step5
conn.execute(query)