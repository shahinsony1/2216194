import sqlite3
"Bootcamp2023.db"
conn=sqlite3.connect("Bootcamp2023.db")
print(conn)

'''
insert into table_name values('','',...)
'''
conn.execute("insert into participants values(2213192,'shahin','cse','btech','areefahnk@gmail.com')")
conn.execute("insert into participants values(2213193,'phahin','ese','btech','sareefahnk@gmail.com')")
conn.execute("insert into participants values(2213194,'chahin','cse','btech','pareefahnk@gmail.com')")
conn.execute("insert into participants values(2213195,'thahin','ese','btech','tareefahnk@gmail.com')")
conn.execute("insert into participants values(2213196,'rhahin','cse','btech','rareefahnk@gmail.com')")

print(conn.total_changes)
conn.commit()
conn.close()