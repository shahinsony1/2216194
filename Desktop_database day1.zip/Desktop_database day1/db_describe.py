import sqlite3
"Bootcamp2023.db"
conn=sqlite3.connect("Bootcamp2023.db")
print(conn)
query='''
         pragma table_info(participants)
       '''
details=conn.execute(query)
print(details)
for i in details:
    print(i)