import sqlite3
"Bootcamp2023.db"
conn=sqlite3.connect("Bootcamp2023.db")
print(conn)
# add a new column -mail_id into already existing table
''''
alter table table_name add column column_name datatype constraints
'''
conn.execute('alter table participants add column mail_id text not null')
conn.commit()
conn.close()
